# Youtube_text_view

Extension made for google Chrome with Javascript.

Displays a clean overlay on YouTube showing only video titles. Helps users choose videos thoughtfully without being distracted by clickbait.
