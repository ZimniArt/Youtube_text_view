# Youtube_text_view

This extension takes youtube page and turns it in compact view with minimal video information you need. No big thumbnails anymore

in format 

How to Build X in 5 Minutes — by Fireship. 142k views. 3 days ago
New AI Model Just Dropped — by ColdFusion. 1.2M views. 1 week ago
Linux Tips Every User Should Know — by LearnLinuxTV. 87k views. 2 days ago
